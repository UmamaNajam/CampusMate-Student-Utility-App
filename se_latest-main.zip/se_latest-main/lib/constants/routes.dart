const loginRoute = '/login/';
const registerRoute = '/register/';
const notesRoute = '/notes/';
const verifyEmailRoute = '/verify-email/';
const createOrUpdateNoteRoute = '/notes/new-note/';

const mainMenuRoute = '/menu/';
const resourceRoute = '/resource';
const gpaRoute = '/gpa';
const sgpaRoute = '/sgpa';
const timeTableRoute = '/timetable';
const mapsRoute = '/maps';
